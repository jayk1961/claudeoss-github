// content.js - Core automation logic for Grocery Coupon Auto-Clicker
// Full version from user paste - production ready

let isRunning = false;
let settings = {
  clickDelay: 850,
  scrollDelay: 650,
  maxRetries: 4,
  batchSize: 1,
  humanLike: true
};

async function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['clickDelay', 'scrollDelay', 'maxRetries', 'batchSize', 'humanLike'], (result) => {
      if (result.clickDelay) settings.clickDelay = result.clickDelay;
      if (result.scrollDelay) settings.scrollDelay = result.scrollDelay;
      if (result.maxRetries) settings.maxRetries = result.maxRetries;
      if (result.batchSize) settings.batchSize = result.batchSize;
      if (result.humanLike !== undefined) settings.humanLike = result.humanLike;
      resolve(settings);
    });
  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function sendStatus(message, progress = null, total = null) {
  chrome.runtime.sendMessage({
    action: 'updateStatus',
    message: message,
    progress: progress,
    total: total
  }).catch(() => {});
}

function findUnclickedButtons() {
  const candidates = Array.from(document.querySelectorAll(
    'button, [role="button"], a, div[onclick], span[onclick], ' +
    '[class*="btn"], [class*="button"], [class*="clip"], [class*="coupon"], ' +
    '[class*="deal"], [class*="offer"], [class*="save"], [class*="add"]'
  ));
  
  return candidates.filter(el => {
    if (!el || el.disabled === true || el.getAttribute('aria-disabled') === 'true') return false;
    const text = (el.innerText || el.textContent || '').trim().toLowerCase();
    if (!text) return false;
    
    const isTarget = 
      text.includes('clip coupon') || text === 'clip' ||
      (text.includes('clip') && text.length < 20) ||
      text.includes('activate') || text.includes('send to card') ||
      text.includes('shop this deal') || text.includes('send this deal') ||
      text.includes('add to card') || text.includes('save') || text.includes('get this deal');
    
    if (!isTarget) return false;
    
    if (text.includes('clipped') || text.includes('already') || text.includes('added') || 
        text.includes('saved') || text.includes('activated') || text.includes('on card')) {
      return false;
    }
    
    const parent = el.closest('div, article, section, li, .card, .offer, .deal') || el.parentElement;
    if (parent) {
      const pText = (parent.innerText || '').toLowerCase();
      if (pText.includes('clipped') || pText.includes('already clipped')) return false;
      if (parent.className && (parent.className.includes('clipped') || parent.className.includes('success'))) return false;
    }
    return true;
  });
}

function findLoadMoreButton() {
  const candidates = Array.from(document.querySelectorAll(
    'button, a, [role="button"], [class*="load"], [class*="more"], .load-more, .show-more, .btn-more'
  ));
  return candidates.find(el => {
    if (!el || el.disabled === true) return false;
    const text = (el.innerText || el.textContent || '').trim().toLowerCase();
    return text.includes('load more') || text.includes('show more') || text === 'more' ||
           text.includes('see more') || text.includes('view more');
  });
}

async function scrollToBottom() {
  sendStatus('Scrolling to load all deals...');
  let previousHeight = 0;
  let stableCount = 0;
  const maxStable = 3;
  
  while (stableCount < maxStable) {
    const currentHeight = document.body.scrollHeight;
    window.scrollTo(0, currentHeight);
    await sleep(settings.scrollDelay);
    const newHeight = document.body.scrollHeight;
    if (newHeight === previousHeight) stableCount++; else { stableCount = 0; previousHeight = newHeight; }
    window.scrollBy(0, 800);
    await sleep(300);
  }
  window.scrollTo(0, document.body.scrollHeight);
  await sleep(800);
  sendStatus('Finished scrolling - all deals loaded.');
}

async function clickAllCoupons() {
  if (isRunning) { sendStatus('Already running!'); return { success: false, message: 'Already running' }; }
  isRunning = true;
  await loadSettings();
  
  const isSafeway = window.location.hostname.includes('safeway');
  const siteName = isSafeway ? 'Safeway' : (window.location.hostname.includes('cvs') ? 'CVS' : 'Generic');
  sendStatus(`Starting ${siteName} coupon auto-clicker...`);
  
  let totalClicked = 0;
  let iterations = 0;
  const MAX_ITERATIONS = 60;
  let noProgressStreak = 0;
  
  while (iterations < MAX_ITERATIONS && noProgressStreak < 5) {
    iterations++;
    await scrollToBottom();
    await sleep(400);
    
    const clipButtons = findUnclickedButtons();
    
    if (clipButtons.length > 0) {
      sendStatus(`Found ${clipButtons.length} buttons. Clicking...`, totalClicked, totalClicked + clipButtons.length);
      const batchSize = Math.max(1, Math.min(10, settings.batchSize || 1));
      
      for (let i = 0; i < clipButtons.length; i += batchSize) {
        const batch = clipButtons.slice(i, i + batchSize);
        try {
          await Promise.all(batch.map(async (btn, idx) => {
            if (batchSize > 1 && idx > 0) await sleep(12);
            btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
            const preDelay = settings.humanLike ? 90 : 12;
            await sleep(preDelay);
            btn.click();
            totalClicked++;
            sendStatus(`Clicked ${totalClicked} so far...`, totalClicked);
          }));
          const interDelay = batchSize > 1 ? Math.max(1, Math.floor(settings.clickDelay / 4)) : 
                           (settings.humanLike ? settings.clickDelay + (Math.random() * 280 - 90) : settings.clickDelay);
          await sleep(Math.max(1, interDelay));
        } catch (e) { console.warn('Batch click error:', e); }
      }
      noProgressStreak = 0;
      await sleep(300);
      continue;
    }
    
    const loadMoreBtn = findLoadMoreButton();
    if (loadMoreBtn) {
      try {
        loadMoreBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await sleep(180);
        loadMoreBtn.click();
        sendStatus(`Clicked "Load More"...`);
        await sleep(850);
        continue;
      } catch (e) {}
    }
    
    sendStatus('No more buttons. Final check...');
    await sleep(900);
    window.scrollBy(0, 1200); await sleep(600);
    window.scrollBy(0, 1200); await sleep(600);
    
    const finalCheck = findUnclickedButtons();
    if (finalCheck.length === 0 && !findLoadMoreButton()) break;
    else noProgressStreak++;
  }
  
  sendStatus('Final verification...');
  await scrollToBottom(); await sleep(500);
  const remaining = findUnclickedButtons();
  
  if (remaining.length > 0) {
    sendStatus(`⚠️ ${remaining.length} still remaining. Final pass...`);
    for (const btn of remaining) { try { btn.click(); totalClicked++; await sleep(180); } catch(e){} }
  } else {
    sendStatus(`✅ SUCCESS! All deals clipped on ${siteName}!`, totalClicked, totalClicked);
  }
  
  isRunning = false;
  return { success: remaining.length === 0, totalClicked, remaining: remaining.length };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'startClicking') {
    clickAllCoupons().then(result => sendResponse(result)).catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (message.action === 'getStatus') { sendResponse({ isRunning, settings }); return true; }
  if (message.action === 'stop') { isRunning = false; sendResponse({ success: true }); return true; }
});
